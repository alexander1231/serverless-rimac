
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'x4nd3r',
  applicationName: 'rimac-app',
  appUid: 'R1tJm0ppr9XggkV6Tp',
  orgUid: '66784d8a-cc19-4846-a3a4-431157a12be6',
  deploymentUid: '701a8d59-7107-48e9-a935-3925bb6e5d75',
  serviceName: 'rimac',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'rimac-dev-convertir', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.convertir, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}